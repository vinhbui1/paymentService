#include <iostream>

bool kiem_tra_doi_xung(float mang[], int do_dai) {
    for (int i = 0; i < do_dai / 2; ++i) {
        if (mang[i] != mang[do_dai - i - 1]) {
            return false;  // Nếu phát hiện khác nhau, mảng không đối xứng
        }
    }
    return true;  // Nếu không có khác nhau nào, mảng đối xứng
}

int main() {
    // Khai báo và khởi tạo mảng số thực
    float mang_so_thuc[] = {0.8, 5.6, 9.1, 7.3, 10, 7.3, 9.1, 5.6, 0.8};

    // Độ dài của mảng
    int do_dai = sizeof(mang_so_thuc) / sizeof(mang_so_thuc[0]);

    // Kiểm tra mảng có đối xứng hay không
    if (kiem_tra_doi_xung(mang_so_thuc, do_dai)) {
        std::cout << "Mang la doi xung." << std::endl;
    } else {
        std::cout << "Mang khong doi xung." << std::endl;
    }

    return 0;
}

#include <iostream>
#include <cstdlib>
#include <ctime>

int random_trong_khoang(int min, int max) {
    return rand() % (max - min + 1) + min;
}

bool kiem_tra_trung_nhau(int mang[], int do_dai, int gia_tri) {
    for (int i = 0; i < do_dai; ++i) {
        if (mang[i] == gia_tri) {
            return true;  // Phát hiện giá trị trùng nhau
        }
    }
    return false;  // Không có giá trị trùng nhau
}

int main() {
    // Khởi tạo seed cho hàm rand
    srand(static_cast<unsigned>(time(0)));

    int n = random_trong_khoang(8, 15);  // Độ dài ngẫu nhiên từ 8 đến 15
    int mang[n];

    for (int i = 0; i < n; ++i) {
        int gia_tri;

        do {
            gia_tri = random_trong_khoang(-369, 369);
        } while (kiem_tra_trung_nhau(mang, i, gia_tri));

        mang[i] = gia_tri;
    }

    std::cout << "Do dai mang: " << n << std::endl;
    std::cout << "Mang moi: ";
    for (int i = 0; i < n; ++i) {
        std::cout << mang[i] << " ";
    }
    std::cout << std::endl;

    return 0;
}

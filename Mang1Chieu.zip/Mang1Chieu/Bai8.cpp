#include <iostream>
#include <cmath>

bool la_so_nguyen_to(int n) {
    if (n < 2) {
        return false;  // Không phải số nguyên tố nếu nhỏ hơn 2
    }

    for (int i = 2; i <= sqrt(n); ++i) {
        if (n % i == 0) {
            return false;  // Không phải số nguyên tố nếu có ước khác 1 và chính nó
        }
    }

    return true;  // Nếu không có ước nào ngoài 1 và chính nó, là số nguyên tố
}

bool la_so_chinh_phuong(int n) {
    int can_bac_2 = sqrt(n);
    return can_bac_2 * can_bac_2 == n;
}

int main() {
    int mang[] = {4, 7, 9, 11, 16, 19, 25, 29};

    // Độ dài của mảng
    int do_dai = sizeof(mang) / sizeof(mang[0]);

    bool co_so_nguyen_to = false;
    bool co_so_chinh_phuong = false;

    for (int i = 0; i < do_dai; ++i) {
        if (la_so_nguyen_to(mang[i])) {
            co_so_nguyen_to = true;
        }

        if (la_so_chinh_phuong(mang[i])) {
            co_so_chinh_phuong = true;
        }
    }

    if (co_so_nguyen_to) {
        std::cout << "Mang chua it nhat mot so nguyen to." << std::endl;
    } else {
        std::cout << "Mang khong chua so nguyen to." << std::endl;
    }

    if (co_so_chinh_phuong) {
        std::cout << "Mang chua it nhat mot so chinh phuong." << std::endl;
    } else {
        std::cout << "Mang khong chua so chinh phuong." << std::endl;
    }

    return 0;
}

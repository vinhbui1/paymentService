#include <iostream>

int main() {
    // Khai báo và khởi tạo mảng số thực
    float mang_so_thuc[] = {0.8, 5.6, 9.1, 7.3, 10, 5.9, 7.2, 9.3, 8.0, 8.7};

    // In mảng
    std::cout << "Mang so thuc: ";
    for (float gia_tri : mang_so_thuc) {
        std::cout << gia_tri << " ";
    }
    std::cout << std::endl;

    return 0;
}
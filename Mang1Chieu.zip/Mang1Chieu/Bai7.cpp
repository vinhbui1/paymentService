#include <iostream>

bool la_mang_con(int mang_cha[], int do_dai_cha, int mang_con[], int do_dai_con) {
    if (do_dai_con > do_dai_cha) {
        return false;  // Mảng con không thể dài hơn mảng cha
    }

    for (int i = 0; i <= do_dai_cha - do_dai_con; ++i) {
        bool la_mang_con = true;

        for (int j = 0; j < do_dai_con; ++j) {
            if (mang_cha[i + j] != mang_con[j]) {
                la_mang_con = false;
                break;  // Nếu phát hiện một phần tử khác nhau, thoát vòng lặp
            }
        }

        if (la_mang_con) {
            return true;  // Nếu tìm thấy mảng con, trả về true
        }
    }

    return false;  // Không tìm thấy mảng con
}

int main() {
    int mang_cha[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    int mang_con1[] = {3, 4, 5};
    int mang_con2[] = {6, 7, 8};

    int do_dai_cha = sizeof(mang_cha) / sizeof(mang_cha[0]);
    int do_dai_con1 = sizeof(mang_con1) / sizeof(mang_con1[0]);
    int do_dai_con2 = sizeof(mang_con2) / sizeof(mang_con2[0]);

    if (la_mang_con(mang_cha, do_dai_cha, mang_con1, do_dai_con1)) {
        std::cout << "Mang con 1 la mang con cua mang cha." << std::endl;
    } else {
        std::cout << "Mang con 1 khong la mang con cua mang cha." << std::endl;
    }

    if (la_mang_con(mang_cha, do_dai_cha, mang_con2, do_dai_con2)) {
        std::cout << "Mang con 2 la mang con cua mang cha." << std::endl;
    } else {
        std::cout << "Mang con 2 khong la mang con cua mang cha." << std::endl;
    }

    return 0;
}

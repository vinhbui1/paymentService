#include <iostream>

bool kiem_tra_tang_dan(float mang[], int do_dai) {
    for (int i = 1; i < do_dai; ++i) {
        if (mang[i] < mang[i - 1]) {
            return false;  // Nếu phát hiện không tăng dần, trả về false
        }
    }
    return true;  // Nếu tất cả các phần tử đều tăng dần, trả về true
}

int main() {
    float mang_so_thuc[] = {0.8, 5.6, 9.1, 7.3, 10, 7.3, 9.1, 5.6, 0.8};

    // Độ dài của mảng
    int do_dai = sizeof(mang_so_thuc) / sizeof(mang_so_thuc[0]);

    // Kiểm tra mảng có tăng dần hay không
    if (kiem_tra_tang_dan(mang_so_thuc, do_dai)) {
        std::cout << "Mang tang dan." << std::endl;
    } else {
        std::cout << "Mang khong tang dan." << std::endl;
    }

    return 0;
}

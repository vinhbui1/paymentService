#include <iostream>
#include <cstdlib>
#include <ctime>

int random_trong_khoang(int min, int max) {
    return rand() % (max - min + 1) + min;
}

int main() {
    // Khởi tạo seed cho hàm rand
    srand(static_cast<unsigned>(time(0)));

    // Số lượng phần tử ngẫu nhiên từ 8 đến 15
    int n = random_trong_khoang(8, 15);

    // Tạo mảng với n phần tử
    int mang[n];

    // Giá trị đối xứng: tạo nửa đầu mảng
    for (int i = 0; i < n / 2; ++i) {
        mang[i] = random_trong_khoang(-51, 78);
        mang[n - i - 1] = mang[i];  // Phần tử đối xứng
    }

    // Nếu n là số lẻ, thì giữ lại phần tử ở giữa
    if (n % 2 != 0) {
        mang[n / 2] = random_trong_khoang(-51, 78);
    }

    // In mảng
    std::cout << "Do dai mang: " << n << std::endl;
    std::cout << "Mang moi: ";
    for (int i = 0; i < n; ++i) {
        std::cout << mang[i] << " ";
    }
    std::cout << std::endl;

    return 0;
}
